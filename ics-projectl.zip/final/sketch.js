var backgroundColor;
var btnStart;
var btnNext;
var btnReset;
var btnBack;
var btnRetry;
var state = 0;


function preload(){
  btnStart = loadImage("img/butStart.png");
  btnBack = loadImage("img/back1.png");
  btnNext = loadImage("img/next2.png");
  btnReset = loadImage("img/butReset.png");
  btnRetry = loadImage("img/butRetry.png");
}

function setup() {
    createCanvas(800, 500);
    backgroundColor = color(255, 255, 255);
    btnStart = new cButtons(btnStart, "Start", 400, 250);
    btnBack = new cButtons(btnBack, "Back", 60, 430);
    btnNext = new cButtons(btnNext, "Next", 640, 430);
    btnReset = new cButtons(btnReset, "Reset", 400, 430);
    btnRetry = new cButtons(btnRetry, "Retry", 400, 250);
}

// Constructor of buttons object
function cButtons(tImg, tName, tPosX, tPosY) {
    //Properties
    this.img = tImg;
    this.name = tName;
    this.PosX = tPosX;
    this.PosY = tPosY;
    //Methonds
    //Draw the button based on Properties
    this.display = function (){
      image(this.img, this.PosX, this.PosY);
    }
    //Type of button based on name
    this.clicked = function (){
      if (mouseX >= this.PosX && mouseX <= this.PosX + 115 && mouseY >= this.PosY && mouseY <= this.PosY + 46) {

        if (this.name == "Next"){
          state ++;
        }
        if (this.name == "Back"){
          state --;
        }
        if (this.name == "Reset"){
          state = 0;
        }
        if (this.name == "Start"){
          state = 1;
        }
        if (this.name == "Retry"){
          state = 1;
        }
      }
      //Calculate clicable position

    }
}

function mousePressed() {
  btnStart.clicked();
  btnNext.clicked();
  btnBack.clicked();
  btnReset.clicked();
  btnRetry.clicked();

}

function start() {
    background(200);
    btnStart.display();


}

function draw(){
        if (state == 0) {
    		start(); //start
    	} else if (state == 1) {
    		menu_base(); //base
    	} else if (state == 2) {
    		menu_flavor(); //flavor
    	} else if (state == 3) {
    		menu_toppings(); //toppings
    	} else if (state == 4) {
    		menu_calories(); //calories
    	} else if (state == 5) {
    		menu_activity(); //activity
    	} else if (state == 6) {
    		menu_result();  //result
    	} else if (state == 7) {
    		retry(); // try again
    	}

}



function menu_base() {
    background(51);
    fill(255);
    textSize(24);
    textFont("sans-serif");
    text("pick your base", 30, 50);
    btnBack.display();
    btnNext.display();
    btnReset.display();
}
function menu_flavor() {
    background(51);
    fill(255);
    textSize(24);
    textFont("sans-serif");
    text("pick your flavor", 30, 50);
    btnBack.display();
    btnNext.display();
    btnReset.display();
}

function menu_toppings() {
    background(51);
    fill(255);
    textSize(24);
    textFont("sans-serif");
    text("pick your toppings", 30, 50);
    btnBack.display();
    btnNext.display();
    btnReset.display();
}

function menu_calories() {
    background(51);
    fill(255);
    textSize(24);
    textFont("sans-serif");
    text("calories", 30, 50);
    btnBack.display();
    btnNext.display();
    btnReset.display();
}

function menu_activity() {
    background(51);
    fill(255);
    textSize(24);
    textFont("sans-serif");
    text("pick an activity", 30, 50);
    btnBack.display();
    btnNext.display();
    btnReset.display();
}

function menu_result() {
    background(51);
    fill(255);
    textSize(24);
    textFont("sans-serif");
    text("result", 30, 50);
    btnBack.display();
    btnNext.display();
    btnReset.display();
}
function retry() {
    background(backgroundColor);
    btnRetry.display();

}
